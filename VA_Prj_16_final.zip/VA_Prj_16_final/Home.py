import streamlit as st

st.set_page_config(
    page_title="Multipage App",
    page_icon="👋",
)

st.title("*Analysis of Movie Dataset*")

st.header("*Project Goal*")

st.markdown("To create visualizations on Movie Dataset i.e., which has attributes such as Name of the Movie, Rating, Genre, Released Year, Score, Details of Actors, Directors, Writers, Gross and Budget of the movie etc., which helps to analyze the patterns such as the Profit for the companies, which genre movies are released more etc.,")

st.header("*Submitted by*")
st.markdown("Veda Samhitha Dyawanapally")
st.markdown("Penuel Odiaka")
st.markdown("Jakob Stallard")
st.markdown("Jaswanth Yadla")


